from langchain.agents import initialize_agent, AgentType
from tools.search_tool import search_tool
from tools.summarizer_tool import summarizer_tool
from tools.aggregator_tool import aggregator_tool
from config.llm_config import llm

function_agent = initialize_agent(
    tools=[search_tool, summarizer_tool, aggregator_tool],
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)
