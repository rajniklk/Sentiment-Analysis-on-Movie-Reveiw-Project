from langchain.agents import initialize_agent, AgentType
from tools.technical_tools import technical_tool_1
from config.llm_config import llm

technical_agent = initialize_agent(
    tools=[technical_tool_1],
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)
