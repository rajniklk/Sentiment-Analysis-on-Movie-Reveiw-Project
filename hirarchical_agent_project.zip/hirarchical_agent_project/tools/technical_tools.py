from langchain.tools import tool

@tool
def technical_tool_1(input: str) -> str:
    return f"Technical response to: {input}"
