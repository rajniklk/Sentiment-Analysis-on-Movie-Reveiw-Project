from langchain.tools import tool

@tool
def aggregator_tool(info1: str, info2: str) -> str:
    return f"Aggregated: [{info1}] + [{info2}]"
