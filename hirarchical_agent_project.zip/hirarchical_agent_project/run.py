from graph.langgraph_flow import build_graph

graph_executor = build_graph()

result = graph_executor.invoke({
    "input": "Summarize search results for generative AI",
    "sub_agent": "function",
    "tools": ["search_tool", "summarizer_tool"]
})

print("Final Result:", result["result"])
