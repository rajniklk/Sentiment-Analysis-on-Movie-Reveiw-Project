from langchain.tools import tool

@tool
def search_tool(query: str) -> str:
    return f"Search results for: {query}"
