from langgraph.graph import StateGraph, END
from agents.function_agent import function_agent
from agents.technical_agent import technical_agent
from tools.aggregator_tool import aggregator_tool

def main_agent_node(state):
    if state["sub_agent"] == "function":
        return "function_agent"
    else:
        return "technical_agent"

def function_agent_node(state):
    tools = state["tools"]
    user_input = state["input"]
    results = []

    for tool in tools:
        result = function_agent.run(f"Use {tool} on: {user_input}")
        results.append(result)

    if len(results) > 1:
        final_response = aggregator_tool.run(info1=results[0], info2=results[1])
        return {"result": final_response}
    return {"result": results[0]}

def technical_agent_node(state):
    response = technical_agent.run(state["input"])
    return {"result": response}

def build_graph():
    workflow = StateGraph()
    workflow.add_node("main_agent", main_agent_node)
    workflow.add_node("function_agent", function_agent_node)
    workflow.add_node("technical_agent", technical_agent_node)
    workflow.set_entry_point("main_agent")
    workflow.add_edge("main_agent", "function_agent")
    workflow.add_edge("main_agent", "technical_agent")
    workflow.add_edge("function_agent", END)
    workflow.add_edge("technical_agent", END)
    return workflow.compile()
