from langchain.tools import tool

@tool
def summarizer_tool(text: str) -> str:
    return f"Summary of: {text}"
